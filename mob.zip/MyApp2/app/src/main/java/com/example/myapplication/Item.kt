package com.example.myapplication

import android.media.audiofx.AudioEffect.Descriptor

class Item(val id:Int, val image:String,val title:String,val description:String,val text:String,val price:Int) {

}
