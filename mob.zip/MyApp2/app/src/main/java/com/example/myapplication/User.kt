class User(val login: String,val email: String,val pass:String) {

}